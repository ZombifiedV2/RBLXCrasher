﻿using System;
using System.Threading;

namespace BackgroundConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
          
            var handle = System.Diagnostics.Process.GetCurrentProcess().MainWindowHandle;
            ShowWindow(handle, 0); 

      
            while (true)
            {
                Thread.Sleep(1000); 
            }
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    }
}
